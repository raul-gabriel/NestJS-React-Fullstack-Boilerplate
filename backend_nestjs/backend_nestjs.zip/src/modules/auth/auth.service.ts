import {
  BadRequestException,
  Injectable,
  UnauthorizedException
} from '@nestjs/common';
import { Response } from 'express';
import { JwtService } from '@nestjs/jwt';
import { InjectEntityManager } from '@nestjs/typeorm';
import type { EntityManager } from 'typeorm';
import type { LoginDTO } from './dto/login.dto';
import { CodificadorService } from '../../core/common/codificador.service';

interface UserData {
  id: number;
  nombres: string;
  tipo_usuario: string;
  mensaje: string;
}

interface ValidationResult {
  success: boolean;
  data?: UserData;
  mensaje?: string;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtService,
    @InjectEntityManager() private readonly entityManager: EntityManager,
    private readonly codificador: CodificadorService,
  ) { }

  async login(loginDto: LoginDTO, res: Response): Promise<{ user: object }> {
    const { username, password } = loginDto;

    if (!username || !password) {
      throw new BadRequestException('Credenciales inválidas');
    }

    let user: any;
    try {
      const [rows] = await this.entityManager.query(
        'CALL IniciarSesion(?, ?)',
        [username, password],
      );
      user = rows?.[0];
    } catch {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    if (!user || Number(user.cod) !== 1) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    const access_token = this.jwtService.sign({
      id: user.id,
      name: user.nombres,
      roles: user.tipo_usuario,
    });

    // almacenar token en cookie HttpOnly
    res.cookie('access_token', access_token, {
      httpOnly: true,
      secure: true,        // cambiar a false si usas HTTP en desarrollo
      sameSite: 'strict',
      maxAge: 1000 * 60 * 60 * 8, // 8 horas
    });

    // retornar datos del perfil
    return {
      user: {
        id: user.id,
        name: user.nombres,
        roles: user.tipo_usuario,
      }
    };
  }



}