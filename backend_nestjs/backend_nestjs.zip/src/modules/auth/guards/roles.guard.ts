import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  ForbiddenException
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';
import { UserRole } from '../../../core/common/enums/roles.enum';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly jwtService: JwtService,
  ) { }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredRoles = this.reflector.getAllAndOverride<UserRole[]>('roles', [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest<Request>();
    const token = this.extractToken(request);

    if (!token) {
      throw new UnauthorizedException('Token no proporcionado');
    }

    let payload: any;
    try {
      payload = await this.jwtService.verifyAsync(token);
    } catch (error: unknown) {
      if (error instanceof Error && error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('El token ha expirado');
      }
      throw new UnauthorizedException('Token inválido');
    }

    let userRoles: UserRole[] = [];
    if (Array.isArray(payload.roles)) {
      userRoles = payload.roles;
    } else if (typeof payload.roles === 'string') {
      userRoles = [payload.roles as UserRole];
    } else {
      throw new UnauthorizedException('Roles del usuario inválidos');
    }

    const hasRole = requiredRoles.some(role => userRoles.includes(role));
    if (!hasRole) {
      throw new ForbiddenException('No tienes permiso para acceder a este recurso');
    }

    return true;
  }

  private extractToken(request: Request): string | undefined {
    // 1. Primero busca en cookie HttpOnly (más seguro)
    if (request.cookies?.access_token) {
      return request.cookies.access_token;
    }
    // 2. Fallback al header Authorization Bearer (compatibilidad)
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}