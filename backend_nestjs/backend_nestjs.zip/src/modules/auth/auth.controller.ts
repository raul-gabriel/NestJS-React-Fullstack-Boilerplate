import { Controller, Post, Get, Body, Req, Res } from '@nestjs/common';
import type { Response } from 'express';

import { AuthService } from './auth.service';
import { LoginDTO } from './dto/login.dto';
import { Auth } from './decorators/auth.decorator';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  // Iniciar sesión (http://localhost:3000/api/auth/login) (json)
  //si la sesion es correcta se devuelve el perfil del usuario, y almacena el token en una cookie httpOnly
  @Post('login')
  async login(@Body() loginDto: LoginDTO, @Res({ passthrough: true }) res: Response) {
    const result = await this.authService.login(loginDto, res);
    return result;
  }


  @Post('logout')
  logout(@Res({ passthrough: true }) res: Response) {
    res.clearCookie('access_token', {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
    });
    return { message: 'Sesión cerrada' };
  }
}