export enum UserRole {
  ADMIN = 'Administrador',
  EDITOR = 'Editor',
  CLIENT = 'Cliente',
}